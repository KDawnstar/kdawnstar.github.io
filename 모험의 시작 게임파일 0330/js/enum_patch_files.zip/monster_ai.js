// ==========================================
// [모험의 시작] 몬스터 AI 모듈 (monster_ai.js)
// ==========================================


const MonsterAICompat = {
    normalizeCondType(type) {
        const t = String(type || '').trim();
        switch (t) {
            case 'COND_ENEMY_IN_RANGE': return 'COND_ENEMY_IN_RANGE';
            case 'COND_PREV_PATTERN': return 'Previous_Pattern';
            case 'COND_SKILL_READY': return 'Skill_No_Cooltime';
            case 'HP_UNDER': return 'HP_UNDER';
            case 'ANIM_TIME_OUT': return 'Anim_Time_Out';
            case 'HIT_BY_ENEMY': return 'Hit_By_Enemy';
            default: return t;
        }
    },
    resolveRangeRef(refValue, m, target, gameState) {
        const ref = String(refValue || '').trim();
        switch (ref) {
            case 'REF_EVADE_RANGE': return m.d.evade;
            case 'REF_ATK_RANGE': return m.d.atkRange;
            case 'REF_CHASE_RANGE': return m.d.chase;
            case 'REF_RECOG_RANGE': return m.d.recog;
            case 'REF_UNRECOG_RANGE': return m.d.unrecog;
            case 'REF_SKILL_USE_RANGE': {
                const skillId = target ? this.resolveTargetPattern(target.split('|')[0].trim(), m) : '';
                const skill = gameState.DB_SKILL[skillId];
                return skill ? (parseFloat(skill.Skill_Use_Range) || 0) : 0;
            }
            default: {
                const n = parseFloat(ref);
                return isNaN(n) ? 0 : n;
            }
        }
    },
    resolvePrevPatternToken(token, m) {
        const t = String(token || '').trim();
        if (!t) return '';
        if (t === 'HIT') return 'P_Hit';
        if (t === 'BOUNDARY') return 'P_Boundary';
        if (t === 'IDLE') return 'P_Idle';
        if (t === 'PATROL') return 'P_Patrol';
        if (t === 'CHASE') return 'P_Chase';
        if (t === 'DIE') return 'P_Die';
        if (t === 'SPAWN') return 'P_Spawn';
        if (t === 'PATTERN_ATK' || t === 'ATK_MELEE | ATK_PROJECTILE') return String(m.d.atkType).toLowerCase() === 'range' ? 'P_Range_ATK' : 'P_Melee_ATK';
        if (t === 'ATK_MELEE') return 'P_Melee_ATK';
        if (t === 'ATK_PROJECTILE') return 'P_Range_ATK';
        if (t === 'P_ATK') return String(m.d.atkType).toLowerCase() === 'range' ? 'P_Range_ATK' : 'P_Melee_ATK';
        return t;
    },
    resolveTargetPattern(target, m) {
        const t = String(target || '').trim();
        if (t === 'P_ATK') return String(m.d.atkType).toLowerCase() === 'range' ? 'P_Range_ATK' : 'P_Melee_ATK';
        return t;
    }
};

const MonsterAI = {
    changeState: function(m, newState, gameState) {
        if (m.forcePrevState) { m.prevState = m.forcePrevState; m.forcePrevState = null; } else { m.prevState = m.state; }
        
        if (m.state === newState) { m.patternCount++; } else { m.patternCount = 1; }
        m.state = newState; m.timer = 0; m.hasFired = false; 
        
        if (newState === 'P_Patrol') { let angle = Math.random() * Math.PI * 2; m.dirX = Math.cos(angle); m.dirY = Math.sin(angle); m.faceDir = m.dirX > 0 ? 1 : -1; }
        if (newState === 'P_Boundary') { 
            m.pacingDir = Math.random() > 0.5 ? 1 : -1; 
            m.pacingAngle = (Math.random() * (Math.PI / 4)) + (Math.PI / 4);
        }
        if (newState === 'P_Melee_ATK') m.nextHitTime = m.d.hitStart;
        
        if (gameState.DB_SKILL[newState]) {
            MonsterSkill.castSkill(m, newState, gameState); // 스킬 모듈 참조로 변경
        }
    },

    getAnimDuration: function(m, gameState) {
        if(m.state === 'P_Idle') return m.d.idleDur;
        if(m.state === 'P_Patrol') return m.d.patrolDur + m.d.patrolStandby;
        if(m.state === 'P_Boundary') return m.d.boundDur + m.d.boundStandby;
        if(m.state === 'P_Evade') return m.d.evadeDur;
        if(m.state === 'P_Range_ATK' || m.state === 'P_Melee_ATK') return m.d.atkDur;
        if(m.state === 'P_Hit') return m.d.hitDur;
        if(m.state === 'P_Spawn') return 1.0;
        if(gameState.DB_SKILL[m.state]) return parseFloat(gameState.DB_SKILL[m.state].Skill_Anim_Duration) || 1.0;
        return 1.0;
    },

    checkFSM: function(m, distX, distY, dist2D, gameState) {
        if (m.state === 'P_Evade' && m.timer < 0.7) return false; 
        if (gameState.DB_SKILL[m.state] && m.timer < parseFloat(gameState.DB_SKILL[m.state].Skill_Anim_Duration)) return false; 

        let aiTypes = String(m.d.aiType).split(',').map(s=>s.trim()); let rules = [];
        aiTypes.forEach(ai => { if(gameState.DB_PATTERN[ai] && gameState.DB_PATTERN[ai]['*']) rules.push(gameState.DB_PATTERN[ai]['*']); });
        aiTypes.forEach(ai => { if(gameState.DB_PATTERN[ai] && gameState.DB_PATTERN[ai][m.state]) rules.push(gameState.DB_PATTERN[ai][m.state]); });

        for(let rule of rules) {
            for(let i=1; i<=8; i++) {
                let type = rule['Pattern_Cond_'+i+'_Type']; let value = rule['Pattern_Cond_'+i+'_Value']; let exType = rule['Pattern_Cond_'+i+'_Extra_Type']; let exVal = rule['Pattern_Cond_'+i+'_Extra_Value']; 
                let ex2Type = rule['Pattern_Cond_'+i+'_Extra_2_Type']; let ex2Val = rule['Pattern_Cond_'+i+'_Extra_2_Value']; let target = rule['Pattern_Cond_'+i+'_To_Pattern'];
                
                if ((type || exType || ex2Type) && target) {
                    if (this.evalCond(m, distX, distY, dist2D, type, value, exType, exVal, ex2Type, ex2Val, target, gameState)) {
                        let patterns = String(target).split('|').map(s=>MonsterAICompat.resolveTargetPattern(s.trim(), m)); let nextPat = patterns[0];
                        
                        if(patterns.length > 1) { 
                            let totalWeight = 0; let weightedList = [];
                            patterns.forEach(pat => {
                                let weight = 1; 
                                let ruleData = null;
                                for(let ai of aiTypes) {
                                    if(gameState.DB_PATTERN[ai] && gameState.DB_PATTERN[ai][pat]) { ruleData = gameState.DB_PATTERN[ai][pat]; break; }
                                }
                                if(ruleData) { 
                                    weight = parseFloat(ruleData.Random_Weight) || 1; 
                                    let rLimit = parseInt(ruleData.Repeat_Limit);
                                    if(!isNaN(rLimit) && m.state === pat && m.patternCount >= rLimit) { weight = 0; }
                                }
                                if(weight > 0) { totalWeight += weight; weightedList.push({ name: pat, weight: weight }); }
                            });
                            
                            if(totalWeight <= 0) { nextPat = 'P_Idle'; } 
                            else {
                                let rand = Math.random() * totalWeight;
                                for(let wp of weightedList) { if(rand < wp.weight) { nextPat = wp.name; break; } rand -= wp.weight; }
                            }
                            if(patterns.includes('P_Melee_ATK') && patterns.includes('P_Range_ATK')) nextPat = String(m.d.atkType).toLowerCase() === 'range' ? 'P_Range_ATK' : 'P_Melee_ATK'; 
                        }
                        
                        if (m.state === nextPat && type !== 'Anim_Time_Out') continue; 
                        this.changeState(m, nextPat, gameState); 
                        return true; 
                    }
                }
            }
        } 

        if (m.timer >= this.getAnimDuration(m, gameState)) {
            this.changeState(m, 'P_Idle', gameState);
            return true;
        }

        return false;
    },

    evalCond: function(m, distX, distY, dist2D, type, value, exType, exVal, ex2Type, ex2Val, target, gameState) {
        let condType = MonsterAICompat.normalizeCondType(type);
        let isTrue = true;
        if (condType) {
            switch(condType) {
                case 'HP_0_Under': isTrue = (m.hp <= 0); break;
                case 'HP_UNDER': isTrue = (m.hp <= (parseFloat(value) || 0)); break;
                case 'Hit_By_Enemy': isTrue = false; break;
                case 'Enemy_In_Evade_Range': isTrue = (m.d.evade > 0 && dist2D <= m.d.evade); break;
                case 'Enemy_Out_Evade_Range': isTrue = (dist2D > m.d.evade); break;
                case 'Enemy_In_ATK_Range': isTrue = (distX <= m.d.atkRange && distY <= 30); break;
                case 'Enemy_In_Chase_Range': isTrue = (dist2D <= m.d.chase); break;
                case 'Enemy_In_Recog_Range': isTrue = (dist2D <= m.d.recog); break;
                case 'Enemy_In_UnRecog_Range': isTrue = (dist2D <= m.d.unrecog); break;
                case 'Enemy_Out_Recog_Range': isTrue = (dist2D > m.d.recog); break;
                case 'Enemy_Out_UnRecog_Range': isTrue = (dist2D > m.d.unrecog); break;
                case 'Enemy_In_Skill_Use_Range': {
                    let skillId = target ? MonsterAICompat.resolveTargetPattern(target.split('|')[0].trim(), m) : '';
                    let skill = gameState.DB_SKILL[skillId];
                    if (skill) { isTrue = (dist2D <= parseFloat(skill.Skill_Use_Range)); } else isTrue = false;
                    break;
                }
                case 'COND_ENEMY_IN_RANGE': {
                    const range = MonsterAICompat.resolveRangeRef(value, m, target, gameState);
                    if (String(value || '').trim() === 'REF_ATK_RANGE') isTrue = (distX <= range && distY <= 30);
                    else isTrue = (dist2D <= range);
                    break;
                }
                case 'Anim_Time_Out': isTrue = (m.timer >= this.getAnimDuration(m, gameState)); break;
                default: isTrue = false;
            }
        }
        let checkEx = (extType, extVal) => {
            if (!extType) return true;
            extType = MonsterAICompat.normalizeCondType(extType);
            if (extType === 'Aggressive_True') return (String(m.d.aggressive).toLowerCase() === "true");
            if (extType === 'Previous_Pattern') return String(extVal).split('|').map(s=>MonsterAICompat.resolvePrevPatternToken(s.trim(), m)).includes(m.prevState);
            if (extType === 'Skill_No_Cooltime') {
                const skillKey = target ? MonsterAICompat.resolveTargetPattern(target.split('|')[0].trim(), m) : '';
                return !(m.skillCooldowns && m.skillCooldowns[skillKey] > 0);
            }
            if (extType === 'HP_UNDER') return (m.hp <= (parseFloat(extVal) || 0));
            if (extType === 'HP_Under_70%') return ((m.hp / m.maxHp) <= 0.7); if (extType === 'HP_Under_50%') return ((m.hp / m.maxHp) <= 0.5); if (extType === 'HP_Under_30%') return ((m.hp / m.maxHp) <= 0.3);
            return true;
        };
        if (isTrue) isTrue = checkEx(exType, exVal); if (isTrue) isTrue = checkEx(ex2Type, ex2Val); return isTrue;
    }
};